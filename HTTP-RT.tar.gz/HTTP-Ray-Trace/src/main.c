#include "http.h"



int main(int argc, char *argv[])
{
    server_start();
    return 0;
}