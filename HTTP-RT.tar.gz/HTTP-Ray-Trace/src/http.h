#include "material.h"
#include "scene.h"
#include "cube.h"
#include "sphere.h"
#include "camera.h"
#include "plugin.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
void intToStr(uint64_t N, char *str);
void server_start();

void server_stop();