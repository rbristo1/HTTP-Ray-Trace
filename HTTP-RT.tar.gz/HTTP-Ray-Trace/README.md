# HTTP-Ray-Trace
## How To Use:
1. Compile with "make"       
2. Run server with ./main
3. Go to [Raytracer](https://web.eecs.utk.edu/~smarz1/courses/cosc360/rtserver.html) and enter server ip (port is always 8177)
4. Enter scene information and click "send to server" to render image in your specified format.      

Website Field information for Raytracer:      
<img width="977" height="1094" alt="image" src="https://github.com/user-attachments/assets/8a3df1bd-4e51-4abc-bc9c-8d1520c5f600" />

Example Output:    


![raytracer(180)](https://github.com/user-attachments/assets/a4d01063-c315-4b44-93b6-01b45de2d2cd)

